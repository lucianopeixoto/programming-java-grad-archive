/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.rms.*;

/**
 * @author Luciano Carvalho Peixoto
 */
public class ProvaMaker extends MIDlet implements CommandListener {
    private Display tela;
	private Form	formMenuPrincipal,
					formQuestao,
					formComeco,
					formFinal;
	private Alert	alertFinalizar,
					alertSobre,
					alertQuestaoSemResposta;
	private ChoiceGroup		grupoRespostas;
	private TextField txtNomeAluno;
	private List listIndice;	
	private Command comandoProxima,
					comandoAnterior,
					comandoIndice,
					comandoConfirmaProva,
					comandoOk,
					comandoRespostaSim,
					comandoRespostaNao,
					comandoProva,
					comandoSair,
					comandoCriarProva,
					comandoResolverProva,
					comandoEditarProva,
					comandoAjuda,
					comandoSobre;
	private ClasseProva prova;
	private int qId = 0, rId= 0;
	private RecordStore pmRecordStore;
	private boolean questaoSemResposta;
	private Image	imageFeita,
					imageBranco,
					imageProvaMaker,
					imageItemMenu,
					imageSair,
					imageInfo,
					imageAjuda;
	private String provaStringada;
	private byte[] data;




	private boolean showQuestao() {
		if (prova.getQuestao(qId) != null && qId >= 0 && qId <50) {
			formQuestao.deleteAll();
			grupoRespostas.deleteAll();
			formQuestao.removeCommand(comandoAnterior);
			formQuestao.removeCommand(comandoProxima);
			if (qId != 0) formQuestao.addCommand(comandoAnterior);
			if (prova.getQuestao(qId+1) != null) formQuestao.addCommand(comandoProxima);
			
			rId = 0;
			tela.setCurrent(formQuestao);
			formQuestao.setTitle(prova.getNomeProva());
			formQuestao.append(new StringItem(((qId+1)+") "), prova.getQuestao(qId).getPergunta()));

			while (prova.getQuestao(qId).getResposta(rId) != null && rId < 8){
				grupoRespostas.append(prova.getQuestao(qId).getResposta(rId).getTexto(), null);
				rId ++;
			}
			if (prova.getQuestao(qId).getSelecionada() != -1){
				grupoRespostas.setSelectedIndex(prova.getQuestao(qId).getSelecionada(), true);
			}
			formQuestao.append(grupoRespostas);
			return true;
		} else return false;
	}

	private void showIndice () {
		qId=0;
		listIndice.deleteAll();
		tela.setCurrent(listIndice);
		while (prova.getQuestao(qId) != null && qId < 50){
			if (prova.getQuestao(qId).getSelecionada() == -1){
				listIndice.append(qId+1 + ") " + prova.getQuestao(qId).getPergunta(), imageBranco);
			}
			else {
				listIndice.append(qId+1 + ") " + prova.getQuestao(qId).getPergunta(), imageFeita);
			}
			
			qId ++;
		}
	}

	private void showFinal () {
		formFinal.append(new StringItem ("Aluno: ", prova.getNomeAluno()));
		formFinal.append(new StringItem ("Prova: ", prova.getNomeProva()));
		formFinal.append(new StringItem ("Professor: ", prova.getNomeProfessor()));
		formFinal.append(new StringItem ("Pontuação: ", prova.getPontuacao() + " Pontos"));
		tela.setCurrent(formFinal);
	}

	private String provaToString (ClasseProva provaOrigem) {
		// Convertendo uma prova em uma string grandona:
		// Instruções para a conversão:
		// stringResultante é a string resultante, provaOrigem é uma ClasseProva
		// qId é uma variavel auxiliar pra representar uma questao e rId
		// para representar uma resposta... Substitui aí pra ficar igual
		// as coisas no seu prog...:

		String stringResultante;

		stringResultante = new String("");
		stringResultante = stringResultante.concat("_prva_");
		stringResultante = stringResultante.concat(provaOrigem.getNomeProva());
		stringResultante = stringResultante.concat("_prof_");
		stringResultante = stringResultante.concat(provaOrigem.getNomeProfessor());
		qId = 0;
		while (provaOrigem.getQuestao(qId) != null && qId < 50) {
			rId=0;
			stringResultante = stringResultante.concat("_ques_" + provaOrigem.getQuestao(qId).getPergunta());
			while (provaOrigem.getQuestao(qId).getResposta(rId) != null && rId < 8) {
				stringResultante = stringResultante.concat("_resp_" + provaOrigem.getQuestao(qId).getResposta(rId).getTexto());
				stringResultante = stringResultante.concat("_pont_" + provaOrigem.getQuestao(qId).getResposta(rId).getPontos());
				rId ++;
			}
			qId ++;
		}
		stringResultante = stringResultante.concat("_fim__");
		return stringResultante;
	}

	public ClasseProva stringToProva (String stringOrigem) {
		ClasseProva provaResultante;
		String textoResposta;
		int pontosResposta = 0;

		System.out.println(stringOrigem+"\n");
		stringOrigem = stringOrigem.substring(6); // Corta logo após o _prva_
		System.out.println(stringOrigem+"\n");
		provaResultante = new ClasseProva (stringOrigem.substring(0, stringOrigem.indexOf('_')));
		stringOrigem = stringOrigem.substring(stringOrigem.indexOf('_')); // Corta apos o nome da prova
		System.out.println(stringOrigem+"\n");

		stringOrigem = stringOrigem.substring(6); // Corta logo após o _prof_
		System.out.println(stringOrigem+"\n");
		provaResultante.setNomeProfessor(stringOrigem.substring(0, stringOrigem.indexOf('_')));
		stringOrigem = stringOrigem.substring(stringOrigem.indexOf('_')); // Corta apos o nome do professor
		System.out.println(stringOrigem+"\n");
		qId = 0;

		while (!stringOrigem.equals("_fim__")){
			rId = 0;
			System.out.println("-> LOOP QUESTAO\n");
			stringOrigem = stringOrigem.substring(6); // Corta logo apos um _ques_
			System.out.println(stringOrigem+"\n");
			provaResultante.addQuestao(stringOrigem.substring(0, stringOrigem.indexOf('_')));
			stringOrigem = stringOrigem.substring(stringOrigem.indexOf('_')); // Corta apos a pergunta
			System.out.println(stringOrigem+"\n");
				
			while (stringOrigem.substring(0, 6).equals("_resp_")){
					System.out.println("-> LOOP RESPOSTA\n");
					stringOrigem = stringOrigem.substring(6); // Corta apos _resp_
					System.out.println(stringOrigem+"\n");
					textoResposta = stringOrigem.substring(0, stringOrigem.indexOf('_'));
					stringOrigem = stringOrigem.substring(stringOrigem.indexOf('_')); // Corta apos a Resposta
					System.out.println(stringOrigem+"\n");

					stringOrigem = stringOrigem.substring(6); // Corta apos _pont_
					System.out.println(stringOrigem+"\n");
					pontosResposta = Integer.parseInt(stringOrigem.substring(0, stringOrigem.indexOf('_')));
					stringOrigem = stringOrigem.substring(stringOrigem.indexOf('_')); // Corta apos os pontos
					System.out.println(stringOrigem+"\n");

					provaResultante.getQuestao(qId).addResposta(textoResposta, pontosResposta);
					rId ++;
					System.out.println("FIM LOOP RESPOSTA\n");
				}
			qId ++;
			System.out.println("FIM LOOP QUESTAO\n");
		}

		return provaResultante;
	}

	public void startApp() {

		//// Abrindo o Rercord Store (FINALMENTE!)
		//try {
		//	pmRecordStore = RecordStore.openRecordStore("ProvaMakerRS", "Vendor", "Midlet");
		//	}
		//catch (RecordStoreException ex) {
		//	ex.printStackTrace();
		//	}

		// Setando o display:
		tela = Display.getDisplay(this);

		System.out.println("Imagens...");
		// Setando as imagens
		try {
			imageFeita = Image.createImage("/Feita.png");
			} catch (java.io.IOException e) {
				e.printStackTrace();
			}
		try {
			imageBranco = Image.createImage("/Branco.png");
			} catch (java.io.IOException e) {
				e.printStackTrace();
			}
		try {
			imageProvaMaker = Image.createImage("/provamaker.png");
			} catch (java.io.IOException e) {
				e.printStackTrace();
			}
		try {
			imageItemMenu = Image.createImage("/itemmenu.png");
			} catch (java.io.IOException e) {
				e.printStackTrace();
			}
		try {
			imageSair = Image.createImage("/sair.png");
			} catch (java.io.IOException e) {
				e.printStackTrace();
			}
		try {
			imageInfo = Image.createImage("/info.png");
			} catch (java.io.IOException e) {
				e.printStackTrace();
			}
		try {
			imageAjuda = Image.createImage("/ajuda.png");
			} catch (java.io.IOException e) {
				e.printStackTrace();
			}
		System.out.println("OK\n");

		System.out.println("Comandos...");
		// Inicializando os comandos:
		comandoRespostaSim = new Command ("Sim", Command.OK, 1);
		comandoRespostaNao = new Command ("Não", Command.CANCEL, 0);
		comandoOk = new Command ("Ok", Command.OK, 0);
		comandoProva = new Command ("Prova", Command.ITEM, 2);
		comandoSair = new Command ("Sair", Command.EXIT, 5);
		comandoProxima = new Command ("Proxima", Command.OK, 0);
		comandoAnterior = new Command ("Anterior", Command.OK, 1);
		comandoConfirmaProva = new Command ("Finalizar", Command.OK, 2);
		comandoIndice = new Command ("Indice", Command.OK, 2);
		comandoCriarProva = new Command ("Criar Prova", Command.ITEM, 2);
		comandoResolverProva = new Command ("Resolver Prova", Command.ITEM, 1);
		comandoEditarProva = new Command ("Editar Prova", Command.ITEM, 2);
		comandoAjuda = new Command ("Ajuda", Command.HELP, 2);
		comandoSobre = new Command ("Sobre", Command.HELP, 2);
		System.out.println("OK\n");

		System.out.println("formMenuPrincipal...");
		// Criando o formMenuPrincipal
		formMenuPrincipal = new Form("Prova Maker");
		formMenuPrincipal.setCommandListener(this);
		formMenuPrincipal.append(imageProvaMaker);
		formMenuPrincipal.addCommand (comandoCriarProva);
		formMenuPrincipal.addCommand (comandoEditarProva);
		formMenuPrincipal.addCommand (comandoResolverProva);
		formMenuPrincipal.addCommand (comandoAjuda);
		formMenuPrincipal.addCommand (comandoSobre);
		System.out.println("OK\n");


		// Criando o formQuestao e seus comandos:
		formQuestao = new Form ("Prova Maker");
		formQuestao.setCommandListener(this);
		formQuestao.addCommand(comandoConfirmaProva);
		formQuestao.addCommand(comandoIndice);
		formQuestao.addCommand(comandoSair);

		// Criando o grupoRespostas:
		grupoRespostas = new ChoiceGroup ("Respostas:", Choice.EXCLUSIVE);

		// Criando o formFinal e seus comandos:
		formFinal = new Form ("PM - Resumo");
		formFinal.setCommandListener(this);
		formFinal.addCommand(comandoSair);

		// Criando o listIndice e seus comandos:
		listIndice = new List ("PM - Indice", List.IMPLICIT);
		listIndice.setCommandListener(this);
		listIndice.setSelectCommand(comandoOk);
		listIndice.addCommand(comandoConfirmaProva);
		listIndice.addCommand(comandoProva);
		listIndice.addCommand(comandoSair);

		// Criando o alertFinalizar e seus comandos:
		alertFinalizar = new Alert ("Confirmar Prova?",
									"Você gostaria de finalizar a prova agora?",
									null,
									AlertType.CONFIRMATION);
		alertFinalizar.setTimeout(Alert.FOREVER);
		alertFinalizar.setCommandListener(this);
		alertFinalizar.addCommand (comandoRespostaSim);
		alertFinalizar.addCommand (comandoRespostaNao);

		// Criando o formComeco e seus comandos:
		formComeco = new Form ("Prova Maker");
		formComeco.setCommandListener(this);
		formComeco.addCommand (comandoOk);
		formComeco.addCommand(comandoSair);

		// Criando o alertSobre e seus comandos:
		alertSobre = new Alert(	"Prova Maker",
								"Este Programa Foi desenvolvido por Alexandre Lopes e Luciano Peixoto",
								null,
								AlertType.INFO);
		alertSobre.setTimeout(Alert.FOREVER);
		alertSobre.setCommandListener(this);
		alertSobre.addCommand(comandoOk);

		// Criando o alertQuestaoSemResposta e seus comandos:
		alertQuestaoSemResposta = new Alert("Tem certeza?",
											"Alguma(as) questão(ões) ainda não foram respondidas, deseja realmente finalizar?",
											null,
											AlertType.CONFIRMATION);
		alertQuestaoSemResposta.setTimeout (Alert.FOREVER);
		alertQuestaoSemResposta.setCommandListener(this);
		alertQuestaoSemResposta.addCommand(comandoRespostaSim);
		alertQuestaoSemResposta.addCommand(comandoRespostaNao);

		try {
			pmRecordStore = RecordStore.openRecordStore("RecorStorePM", "Vendor", "ProvaMakerEditor");
			data = pmRecordStore.getRecord(0);
		}
		catch (RecordStoreException ex){
		}

//		provaStringada = new String (data);
//		prova = stringToProva (provaStringada);
//
//		txtNomeAluno = new TextField ("Aluno:", prova.getNomeAluno(), 100,	TextField.ANY|
//																	TextField.SENSITIVE|
//																	TextField.NON_PREDICTIVE|
//																	TextField.INITIAL_CAPS_WORD);
//		formComeco.append (new StringItem("Prova: ",prova.getNomeProva()));
//		formComeco.append (new StringItem("Professor: ",prova.getNomeProfessor()));
//		formComeco.append (txtNomeAluno);
//		formComeco.append (new StringItem("Prova: ",provaStringada));
//		tela.setCurrent(formComeco);
//
//		System.out.println("Mostrando o formMenuPrincipal");
//		tela.setCurrent(formMenuPrincipal);
//		System.out.println("OK\n");

		tela.setCurrent (formMenuPrincipal);
	}

    public void pauseApp() {
		
    }

    public void destroyApp(boolean unconditional) {
		try {
			pmRecordStore.closeRecordStore();
		}
		catch (RecordStoreException ex){
		}
    }

    public void commandAction(Command c, Displayable d) {

		if (d == formComeco) {
			if (c == comandoOk)	{
				prova.setNomeAluno(txtNomeAluno.getString());
				showIndice();
			}
			if (c == comandoSair){
				 notifyDestroyed();
			}
		}

		if (d == formFinal) {
			if (c == comandoSair){
				 notifyDestroyed();
			}
		}

		if (d == formQuestao){
			if (c == comandoProxima){
				prova.getQuestao(qId).setSelecionada(grupoRespostas.getSelectedIndex());
				if (prova.getQuestao(qId+1)!= null) qId ++;
				showQuestao ();
			}
			if (c == comandoAnterior){
				prova.getQuestao(qId).setSelecionada(grupoRespostas.getSelectedIndex());
				if (qId > 0) qId --;
				showQuestao ();
			}
			if (c == comandoIndice){
				prova.getQuestao(qId).setSelecionada(grupoRespostas.getSelectedIndex());
				showIndice ();
			}
			if (c == comandoConfirmaProva){
				prova.getQuestao(qId).setSelecionada(grupoRespostas.getSelectedIndex());
				tela.setCurrent(alertFinalizar);
			}
			if (c == comandoSair){
				 notifyDestroyed();
			}
		}

		if (d == listIndice) {
			if (c == comandoOk)	{
				qId = listIndice.getSelectedIndex();
				showQuestao();
			}
			if (c == comandoConfirmaProva){
				tela.setCurrent(alertFinalizar);
			}
			if (c == comandoProva){
				tela.setCurrent(formComeco);
			}
			if (c == comandoSair){
				 notifyDestroyed();
			}
		}

		if (d == alertFinalizar) {
			if (c == comandoRespostaSim)	{
				// Zerando qId e zerando a pontuação:
				qId = 0;
				prova.setPontuacao(0);
				questaoSemResposta = false;
				// Loop para somar os pontos:
				while (prova.getQuestao(qId) != null && qId < 50){
					if (prova.getQuestao(qId).getSelecionada() != -1){
						prova.setPontuacao(prova.getPontuacao() + prova.getQuestao(qId).getResposta(prova.getQuestao(qId).getSelecionada()).getPontos());
					}
					else {
						questaoSemResposta = true; // se alguma questao nao tiver sido respondida seta como TRUE
					}
					qId ++;
				}
				// Verifica se alguma questão ficou sem resposta ou não,
				// caso tem ficado, avisa ao usuario e pede outra confirmação:
				if (questaoSemResposta == true) tela.setCurrent(alertQuestaoSemResposta);
				else showFinal();
			}
			if (c == comandoRespostaNao)	{
				showIndice ();
			}
		}

		if (d == alertQuestaoSemResposta) {
			if (c == comandoRespostaNao) {
				showIndice ();
			}
			if (c == comandoRespostaSim) {
				showFinal ();
			}
		}

		if (d == formMenuPrincipal){
			if (c == comandoCriarProva){
				// Parte reservada para se criar uma prova de exemplo (Futuramente sera substituida pela funcionalidade de criar uma prova):
				// COMEÇO DA PARTE RESERVADA -----
				prova = new ClasseProva("Sistemas Embarcados");
				prova.setNomeProfessor("Jorge Campos");
				prova.addQuestao("1 + 1:");
				prova.getQuestao(0).addResposta("4", 0);
				prova.getQuestao(0).addResposta("3", 0);
				prova.getQuestao(0).addResposta("1", 0);
				prova.getQuestao(0).addResposta("2", 10);
				prova.addQuestao("1 - 1:");
				prova.getQuestao(1).addResposta("10", 0);
				prova.getQuestao(1).addResposta("0", 10);
				prova.addQuestao("Isso é uma pergunta?");
				prova.getQuestao(2).addResposta("Não", 0);
				prova.getQuestao(2).addResposta("Sim", 10);
				prova.getQuestao(2).addResposta("Talvez", 5);
				prova.getQuestao(2).addResposta("Sim! E isso é uma resposta.", 15);
				prova.addQuestao("Oi, tudo bem?");
				prova.getQuestao(3).addResposta("Não", 10);
				prova.getQuestao(3).addResposta("Sim", 0);
				prova.getQuestao(3).addResposta("Talvez", 0);
				// FIM -----

				provaStringada = provaToString(prova);
				data = provaStringada.getBytes();

				try {
					RecordStore.deleteRecordStore("RecordStorePM");
					pmRecordStore = RecordStore.openRecordStore("RecorStorePM", true);
					pmRecordStore.addRecord(data, 0, data.length);
				}
				catch (RecordStoreException ex){
				}

			}
			if (c == comandoResolverProva){
				try {
					pmRecordStore = RecordStore.openRecordStore("RecorStorePM", false);
					data = pmRecordStore.getRecord(0);
				}
				catch (RecordStoreException ex){
				}

				provaStringada = new String (data);
				prova = stringToProva (provaStringada);

				txtNomeAluno = new TextField ("Aluno:", prova.getNomeAluno(), 100,	TextField.ANY|
																			TextField.SENSITIVE|
																			TextField.NON_PREDICTIVE|
																			TextField.INITIAL_CAPS_WORD);
				formComeco.append (new StringItem("Prova: ",prova.getNomeProva()));
				formComeco.append (new StringItem("Professor: ",prova.getNomeProfessor()));
				formComeco.append (txtNomeAluno);
				formComeco.append (new StringItem("Prova: ",provaStringada));

				tela.setCurrent(formComeco);
			}
			if (c == comandoEditarProva) {
				try {
					RecordStore.deleteRecordStore("RecordStorePM");
				}
				catch (RecordStoreException ex){
				}
			}
		}
    }
}